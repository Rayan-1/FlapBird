#ifndef FORMAS_H
#define FORMAS_H


class Formas{
    public:
        Formas();
        static void circulo(int divisoes);
        static void quadrado();
};

#endif // FORMAS_H
